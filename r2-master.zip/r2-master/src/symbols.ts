const symbols = {
  ConfigStore: Symbol('ConfigStore'),  
  BrokerAdapter: Symbol('BrokerAdapter'),
  ActivePairStore: Symbol('ActivePairStore'),
  SpreadStatTimeSeries: Symbol('SpreadStatTimeSeries')
};

export default symbols;
